<!DOCTYPE html>
<html lang="<?php echo e(app()->getLocale()); ?>">
<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- CSRF Token -->


    <title><?php echo e(config('app.name', 'Stock')); ?></title>
    <link rel="stylesheet" href="<?php echo e(asset('fonts/icomoon/style.css')); ?>">



    <!-- Bootstrap CSS -->
    <link rel="stylesheet"   href="<?php echo e(asset('css/bootstrap.min.css')); ?>">

    <!-- Style -->
    <link rel="stylesheet" href="<?php echo e(asset('css/style.css')); ?>">

  <style>



	</style>

</head>
<body>
<div class="cover-spin"></div>

        <?php echo $__env->yieldContent('content'); ?>


    <!-- Scripts -->

</body>
</html>
<?php /**PATH E:\amyapp\aaclientCardStock\DcardSUITE\mdrivers\backend\resources\views/layouts/app.blade.php ENDPATH**/ ?>