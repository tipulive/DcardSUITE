<!-- Main CSS-->
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/flatpickr/dist/flatpickr.min.css">
<link href="https://fonts.googleapis.com/css2?family=Poppins:ital,wght@0,700;1,900&amp;display=swap" rel="stylesheet">
<link href="https://fonts.googleapis.com/css?family=Montserrat|Poppins|Noto+Serif&amp;display=swap" rel="stylesheet">

<!--<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/flatpickr/dist/flatpickr.min.css">
    <link href="https://cdn.datatables.net/1.10.20/css/jquery.dataTables.min.css" rel="stylesheet" media="all">
    <link href="https://cdn.datatables.net/fixedheader/3.1.6/css/fixedHeader.bootstrap.min.css" rel="stylesheet" media="all">
    <link href="https://cdn.datatables.net/responsive/2.2.3/css/responsive.bootstrap.min.css" rel="stylesheet" media="all">

  -->
    <link href="dashboard/main.css?version='<?php echo e(env('APP_VERS')); ?>'" rel="stylesheet">
    <link href="css/mystyle.css?version='<?php echo e(env('APP_VERS')); ?>'" rel="stylesheet">
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.6.3/css/all.css" integrity="sha384-UHRtZLI+pbxtHCWp1t77Bi1L4ZtiqrqD80Kn4Z8NTSRyMA2Fd33n5dQ8lWUE00s/" crossorigin="anonymous">


    <style>

        .rating{
border-radius: 50%;
width: 25px;
height: 25px;

/*font-size: 6vw;
    color: #FFD600;
    background: red;*/
        }




        .myrating:hover{
            color:#FFD600;
            cursor: pointer;
        }
        .myrating-wrapper{
            display: flex;


        }
        .div_center{
            justify-content: center;
        }
        .myrating-wrapper div{
            margin-right: 0.3rem;
        }
       .rating_back{
        color:#FFD600;
       }





        </style>
    <style>
.popover {
    width: 100% !important;
}
.card-img-top{
   width: 100%!important;
   height: 200px!important;
   object-fit: cover;
}
input[type="search"] {
    border: 1px solid;
}
.modal{
    margin-top:60px;
}



</style>

</head>
<?php /**PATH E:\amyapp\aaclientCardStock\DcardSUITE\joeShipping\resources\views/components/header/header.blade.php ENDPATH**/ ?>