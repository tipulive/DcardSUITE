`

<form class="Form_order">
            <!--My Form-->






<div class="form-group">

    <label for="">Search Facture No:<span class="text-danger">*</span></label>


  <input type="text" class="form-control" aria-label="Text input with dropdown button"  onkeyup="return searchSaleFacture(this)">
</div>






</div>
<!--search Form -->
</form>

`
<?php /**PATH E:\amyapp\aaclientCardStock\DcardSUITE\joeShipping\resources\views/components/Search/Search/SearchFactureNo.blade.php ENDPATH**/ ?>