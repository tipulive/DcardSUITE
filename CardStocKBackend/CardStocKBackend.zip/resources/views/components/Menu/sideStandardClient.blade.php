<ul class="vertical-nav-menu Client d-none">
<li class="app-sidebar__heading">Profile</li>
                            
                                <li>
                                    <a id="clientdata" href="#Forms_UpdateProfile" onclick="dynamic_menu('Forms_UpdateProfile')">
                                    <i class="metismenu-icon pe-7s-id"></i>                   
                                    Edit Profile
                                    </a>
                                </li>

                                <li class="app-sidebar__heading">Order Medicine</li>
                                  
                                  <li>
                                          <a href="#orders" >
                                          <i class="metismenu-icon pe-7s-display2"></i>                   
                                         Search  By
                                         <i class="metismenu-state-icon pe-7s-angle-down caret-left"></i>    
                                          </a>
      
                                          <ul>
                                                  <li>
                                                      <a href="#Forms_UserMedecine" onclick="dynamic_menu('Forms_UserMedecine')">
                                                          <i class="metismenu-icon"></i>
                                                          Medicine Name
                                                      </a>
                                                  </li>
                                                  <li>
                                                      <a href="#Forms_UploadPrescription" onclick="dynamic_menu('Forms_UploadPrescription')">
                                                          <i class="metismenu-icon">
                                                          </i>Upload Prescription
                                                      </a>
                                                  </li>
                                                  
                                               
                                                
                                                
                                                  
                                              </ul>
                                      </li>
                        
                            
                              
                         
                            <li class="app-sidebar__heading">Orders</li>
                                  
                            <li>
                                    <a href="#orders" >
                                    <i class="metismenu-icon pe-7s-display2"></i>                   
                                   View Order
                                   <i class="metismenu-state-icon pe-7s-angle-down caret-left"></i>    
                                    </a>

                                    <ul>
                                    <li>
                                    <a href="#" onclick="get_chatrequest_order()">
                                              
                                                    <i class="metismenu-icon"></i>
                                                    Orders Placed
                                                </a>
                                            </li>
                                    <li>
                                    <a href="#Table_Medorders" onclick="dynamic_menu('Table_Medorders')">
                                              
                                                    <i class="metismenu-icon"></i>
                                                    Pending Orders
                                                </a>
                                            </li>
                                            <li>
                                            <a href="#Table_Prescorders" onclick="dynamic_menu('Table_Prescorders')">
                                                    <i class="metismenu-icon">
                                                    </i>Completed orders
                                                </a>
                                            </li>
                                            
                                            
                                         
                                          
                                          
                                            
                                        </ul>
                                </li>

                             
                                <li class="app-sidebar__heading d-none" >Settings</li>
                                
                                <li class="d-none">
                                    <a href="#show_document" onclick="show_document();">
                                    <i class="metismenu-icon pe-7s-display2 "></i>      
                                    Settings
                                    <i class="metismenu-state-icon pe-7s-angle-down caret-left"></i>                   
                                    </a>

                                    <ul class="listinvoice_display">
                                        
                                        
                                       
   
                                    </ul>
                                </li>

                               </ul>

                               