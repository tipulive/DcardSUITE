<div class="au-card visible_div">
<h3 class="title-2 m-b-10 text-center docname"></h3>
<input type="hidden" class="tableid">
<hr>
<div class="table-responsive  m-b-40">
    <br>
   
                    <table id="Table_Prescorders"  class="table table-borderless table-data3" cellspacing="0" width="100%">
                         <thead>

                         @include('components.Table.components.table_Prescorder_client')
                         @include('components.Table.components.table_Prescorder_pharmacy')
                         @include('components.Table.components.table_Prescorder_Super')

                      </thead>
                        
                        
                    </table>
                </div>
                <hr>
                </div>
