{data: 'DT_RowIndex',name:'DT_RowIndex'},
     {data:'uid',name:'OrderID'},
    
    
     {data: 'total_price', name: 'total_price'},
     {data: 'status', name: 'Status'},
     {data: 'pay_mode', name: 'Pay'},
  
     {data: 'created_at', name: 'Created_at'},
     {data: 'action', name: 'action'}

  
     
        
            
                                                   
                    
           
  
               
               
       
   