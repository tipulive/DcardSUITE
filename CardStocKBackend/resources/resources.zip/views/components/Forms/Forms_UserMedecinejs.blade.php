<script>

$(function(){
    
   
    get_profile_detail();
    search_address_profile();
               
           });

           
<script>