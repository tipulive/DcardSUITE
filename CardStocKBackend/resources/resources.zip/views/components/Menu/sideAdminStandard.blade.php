<ul class="vertical-nav-menu Standard d-none">
<li class="app-sidebar__heading">Profile</li>
                            
                                <li>
                                    <a href="#Forms_UpdateProfile" onclick="dynamic_menu('Forms_UpdateProfile')">
                                    <i class="metismenu-icon pe-7s-id"></i>                   
                                    Edit Profile
                                    </a>
                                </li>


                                <li class="app-sidebar__heading">Order</li>
                            
                               
                                <li>
                                    <a href="#orders" >
                                    <i class="metismenu-icon pe-7s-display2"></i>                   
                                   View Order
                                   <i class="metismenu-state-icon pe-7s-angle-down caret-left"></i>    
                                    </a>

                                    <ul>
                                    <li class="d-none">
                                    <a href="#" onclick="get_chatrequest_order()">
                                              
                                                    <i class="metismenu-icon"></i>
                                                    Placed Orders
                                                </a>
                                            </li>
                                    <li>
                                    <a href="#Table_Medorders" onclick="dynamic_menu('Table_Medorders')">
                                              
                                                    <i class="metismenu-icon"></i>
                                                    Pending Orders <span class="text-danger not_counter"></span>
                                                </a>
                                            </li>
                                            <li>
                                            <a href="#Table_Prescorders" onclick="dynamic_menu('Table_Prescorders')">
                                                    <i class="metismenu-icon">
                                                    </i>Completed orders
                                                </a>
                                            </li>
                                            
                                            
                                         
                                          
                                          
                                            
                                        </ul>
                                </li>

                                <li class="app-sidebar__heading">Payments</li>
                            
                                <li>
                                    <a href="#Table_Paymenthistory" onclick="dynamic_menu('Table_Paymenthistory')">
                                    <i class="metismenu-icon pe-7s-display2"></i>                   
                                    Billing Statement 
                                    </a>
                                </li>

                                <li class="app-sidebar__heading d-none" >Settings</li>
                                
                                <li class="d-none">
                                    <a href="#show_document" onclick="show_document();">
                                    <i class="metismenu-icon pe-7s-display2 d-none"></i>      
                                    Settings
                                    <i class="metismenu-state-icon pe-7s-angle-down caret-left"></i>                   
                                    </a>

                                    <ul class="listinvoice_display">
                                        
                                        
                                       
   
                                    </ul>
                                </li>

              

                                <li class="app-sidebar__heading d-none" >Invoice</li>
                                
                                <li class="d-none">
                                    <a href="#show_document" onclick="show_document();">
                                    <i class="metismenu-icon pe-7s-display2"></i>      
                                    Customize Invoice
                                    <i class="metismenu-state-icon pe-7s-angle-down caret-left"></i>                   
                                    </a>

                                    <ul class="listinvoice_display">
                                        
                                        
                                       
   
                                    </ul>
                                </li>
                                </ul>